//globals
var canvas;

var leftkey, rightkey, spacekey, xkey;
leftkey = new Image();
leftkey.src = 'LeftKey.png';
rightkey = new Image();
rightkey.src = 'RightKey.png';
spacekey = new Image();
spacekey.src = 'SpaceKey.png';
xkey = new Image();
xkey.src = 'XKey.png';

var cartwheelAttackInfo = new Image();
cartwheelAttackInfo.src = 'CartwheelAttackInfo.png';

var Halfway = false;
var Wholeway = false;

var backgroundScrollX;
var backgroundScrollY;

//var background = new Image();
//background.src = 'TestBackground.png';

var backgroundChunk = new Array(4);
backgroundChunk[0] = new Image();
backgroundChunk[0].src = 'LevelChunk1.png';
backgroundChunk[1] = new Image();
backgroundChunk[1].src = 'LevelChunk2.png';
backgroundChunk[2] = new Image();
backgroundChunk[2].src = 'LevelChunk3.png';
backgroundChunk[3] = new Image();
backgroundChunk[3].src = 'LevelChunk4.png';

var Title = new Image();
Title.src = 'Title.png';

var Flagpole1 = new Image();
Flagpole1.src = 'Flagpole1.png';

var Flagpole2 = new Image();
Flagpole2.src = 'Flagpole2.png';

var UpperPlatform = new Image();
UpperPlatform.src = 'UpperPlatform.png';

var WIDTH = 800;
var HEIGHT = 580;

var clippingMargin = -80;
	
var mobileTouchMargin = 20;

var frameRate = 0;
var currentFrameCount = 0;
var frameTime = (new Date()).getTime();

function initialize(isReset)
{
	canvas = document.getElementById('canvas');
	
	canvas.width = WIDTH;
	canvas.height = HEIGHT;
	var pos = findPos(canvas);
	canvas.left = pos[0];
	canvas.top = pos[1];
	
	canvas.style.visibility = 'visible';
	var loadingdiv = document.getElementById('loadingdiv');
	loadingdiv.style.visibility = 'hidden';	

	if(!Halfway) mainBugsby = new Bugsby(660, 50);
	else mainBugsby = new Bugsby(7700, 250);

	backgroundScrollX = -mainBugsby.X + 390;
	backgroundScrollY = 0;
	
	backgroundScrollVX = 0;
	
	debugMode = false;
	
	Stars = new Array();
	
	Items = new Array();
	
	NumCookies = 0;
	
	SecondEnding = false;
	
	warping = false;
	
	LinkLocation = "http://www.bugsby.net/links.html";
	Linked = false;
	
	isMobile = navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
	
	Mode = 0;
	//Ending = 1;
	
	window.onkeydown = KeyDown;
	window.onkeyup = KeyUp;
	window.onkeypress = KeyPress;
	
	if(!isReset)
	{
		setInterval(Update,40);
	}
	
	document.addEventListener("touchmove", appTouchmove, false);
	document.addEventListener("touchstart", appTouchstart, false);
	document.addEventListener("touchend", appTouchend, false);
	
	BuildLevel();
}

function Update()
{
	// check the frame rate
	var currentTime = (new Date()).getTime();
	var diff = currentTime - frameTime;
	if(currentTime - frameTime > 1000)
	{
		frameTime = currentTime;
		frameRate = currentFrameCount;
		currentFrameCount = 0;
	}
	currentFrameCount += 1;
	
	// if we're not in the regular mode, update the ending
	if(Mode != 0)
	{
		//ha!
		if(SecondEnding)
		{
			FirstEndingUpdate();
		}
		else
		{
			SecondEndingUpdate();
		}
		return;
	}
	
	if(!Wiping)
	{
		// update the background Y scroll
		if(mainBugsby.Y + backgroundScrollY >  HEIGHT * 0.40 && backgroundScrollY > 0)
		{
			backgroundScrollY -= mainBugsby.VY;
			
			if(mainBugsby.Y + backgroundScrollY >  HEIGHT * 0.45)
			{
				backgroundScrollY -= 2;
			}
		}
		
		if(mainBugsby.Y + backgroundScrollY < HEIGHT * 0.25)
		{
			backgroundScrollY -= mainBugsby.VY;
			
			if(mainBugsby.Y + backgroundScrollY < HEIGHT * 0.20)
			{
				backgroundScrollY += 2;
			}
		}
		
		// update the moving and sliding platforms. these have to be moved even if 
		// bugsby is not in their vicinity, in order to avoid world inconsistencies
		for(var i = 0, len = Platforms.length; i < len; i++)
		{
			platform = Platforms[i];
			if(platform.type == "moving" || platform.type == "sliding")
				platform.Update(mainBugsby);
		}
		
		// update bugsby, with the platforms and walls
		mainBugsby.Update();
		
		// require bugsby to be to the right of -200
		if(mainBugsby.X <= -200)
		{
			mainBugsby.X = -200;
		}
		
		// if bugsby is to the right of 16350, he wins!
		if(mainBugsby.X >= 16350)
		{
			Wiping = true;
			WipeCenterX = 16250;
			WipeCenterY = mainBugsby.Y;
			mainBugsby.X = 16350;
		}
		
		// if bugsby has fallen, re-start
		if(mainBugsby.Y >= 2000)
		{
			initialize(true);
		}
		
		if(!mainBugsby.cartwheeling)
		{
			if(mainBugsby.X + backgroundScrollX >  WIDTH * 0.60 && mainBugsby.VX > 0)
			{
				if(mainBugsby.X < 15976)
				{
					backgroundScrollX -= mainBugsby.VX + BugsbyRunPower;
				}
			}
		
			if(mainBugsby.X + backgroundScrollX < WIDTH * 0.40 && mainBugsby.VX < 0)
			{
				if(backgroundScrollX <= -60)
				{
					backgroundScrollX -= mainBugsby.VX - BugsbyRunPower;
				}
			}
		}
		else
		{
			if(mainBugsby.X + backgroundScrollX >  WIDTH * 0.60 && mainBugsby.cartwheelDirection == 1)
				backgroundScrollX -= 10 * BugsbyRunPower;
			else if(mainBugsby.X + backgroundScrollX < WIDTH * 0.40 && mainBugsby.cartwheelDirection == -1)
				backgroundScrollX += 10 * BugsbyRunPower;
		}
		
		if(backgroundScrollY < 0)
		{
			backgroundScrollY = 0;
		}
		
		NewItems = new Array();
		for(var i = 0, len = Items.length; i < len; i++)
		{
			item = Items[i];
			if(Math.abs(item.X - mainBugsby.X) < 1000)
			{
				item.Update(Platforms, mainBugsby);
				if(Math.abs(item.VX) > 5) item.VX *= .9;
			}
			if(!item.grabbed)
			{
				NewItems.push(item);
			}
		}
		Items = NewItems;
		
		cubeBumped = false;
		for(var i = 0, len = Cubes.length; i < len; i++)
		{
			cube = Cubes[i];
			if(Math.abs(cube.X - mainBugsby.X) < 1000)
				cube.Update(mainBugsby);
		}
		
		for(var i = 0, len = Baddies.length; i < len; i++)
		{
			baddie = Baddies[i];
			if(Math.abs(baddie.X - mainBugsby.X) < 1000)
				baddie.Update(Platforms, mainBugsby);
		}
		
		NewStars = new Array();
		for(var i = 0, len = Stars.length; i < len; i++)
		{
			star = Stars[i];
			star.Update();
			if(star.Y < 800)
			{
				NewStars.push(star);
			}
		}
		Stars = NewStars;
	}
	
	if(Wiping)
	{
		WipeInnerRadius -= 40;
		if(WipeInnerRadius < -10)
		{
			WipeInnerRadius = 0;
			Mode = 1;
			//ha!
			if(SecondEnding)
			{
				/*if(WipeInnerRadius < -10 && !Linked)
				{
					Linked = true;
					if(LinkLocation != null)
					{
						document.location.href = LinkLocation
					}
				}*/
				FirstEndingInit();
			}
			else
			{
				SecondEndingInit();
			}
			return;
		}
	}
	
	Draw();
}

function Draw()
{	
	var stuffDrawn = 0;
	
	if(Mode != 0)
	{
		//ha!
		if(SecondEnding)
		{
			FirstEndingDraw();
		}
		else
		{
			SecondEndingDraw();
		}
		return;
	}
	
	var context = canvas.getContext('2d');
	
	//calculate the screen boundaries
		
	lineWidth = 3;
	
	context.clearRect(0,0,canvas.width,canvas.height);
	
	if(!debugMode) context.fillStyle = "#DBFDFF";
	else context.fillStyle = "#DBFDFF";
	
	context.beginPath();
	context.moveTo(0,0);
	context.lineTo(0,canvas.height);
	context.lineTo(canvas.width,canvas.height);
	context.lineTo(canvas.width,0);
	context.fill();
	
	for(var i = 0, len = Clouds.length; i < len; i++)
	{
		cloud = Clouds[i];
		//if(Math.floor(Math.random() * 20) > 10)
		if(cloud.X + cloud.width + backgroundScrollX > clippingMargin
			&& cloud.X + backgroundScrollX < WIDTH - clippingMargin
			 && cloud.Y + cloud.height + backgroundScrollY > clippingMargin
			 	&& cloud.Y + backgroundScrollY < HEIGHT - clippingMargin)
		{
			cloud.Draw(context);
			stuffDrawn += 1;
		}
	}
	
	context.drawImage(Title, backgroundScrollX + 467, backgroundScrollY + 41);
	stuffDrawn += 1;
	
	//I shortened the background by 140 pixels to save space and drawing
	//context.drawImage(background, backgroundScrollX, backgroundScrollY + 140);
	for(var i = 0, len = backgroundChunk.length; i < len; i++)
	{
		if(4401 * (i+1) + backgroundScrollX > clippingMargin && 4401 * i + backgroundScrollX < WIDTH - clippingMargin)
		{
			bg = backgroundChunk[i];
			context.drawImage(bg, backgroundScrollX + 4401 * i, backgroundScrollY + 140);
			stuffDrawn += 1;
		}
	}
	
	
	
	if(debugMode)
	{
		//draw a clipping plane
		context.strokeStyle = "#00FF00";
		context.lineWidth = 2;
	
		context.beginPath();
		context.moveTo(clippingMargin, clippingMargin);
		context.lineTo(WIDTH - clippingMargin, clippingMargin);
		context.lineTo(WIDTH - clippingMargin, HEIGHT - clippingMargin);
		context.lineTo(clippingMargin, HEIGHT - clippingMargin);
		context.lineTo(clippingMargin, clippingMargin);
		context.stroke();
	}

	if(Math.abs(mainBugsby.VX) < 1 && !(isMobile))
	{
		context.drawImage(leftkey, backgroundScrollX + 580, backgroundScrollY + 240);
		context.drawImage(rightkey, backgroundScrollX + 620, backgroundScrollY + 240);
		context.drawImage(spacekey, backgroundScrollX + 660, backgroundScrollY + 240);
		
		stuffDrawn += 3;
	}
	
	if(isMobile)
	{
		//context.drawImage(leftkey, 660, 520);
		//context.drawImage(rightkey, 740, 520);
		//context.drawImage(spacekey, 20, 520);
		// if(mainBugsby.tracksuitPower)
		// 		{
		// 			context.drawImage(xkey, 160, 520);
		// 		}

		if(debugMode)
		{
			// context.strokeStyle = "#00FF00";
			// 	context.lineWidth = 2;
			// 
			// 	context.beginPath();
			// 	context.moveTo(660 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(660 + 36 + mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(660 + 36 + mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(660 - mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(660 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	
			// 	context.moveTo(740 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(740 + 36 + mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(740 + 36 + mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(740 - mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(740 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	
			// 	context.moveTo(20 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(20 + 102 + mobileTouchMargin, 520 - mobileTouchMargin);
			// 	context.lineTo(20 + 102 + mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(20 - mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 	context.lineTo(20 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	
			// 	if(mainBugsby.tracksuitPower)
			// 	{
			// 		context.moveTo(160 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 		context.lineTo(160 + 36 + mobileTouchMargin, 520 - mobileTouchMargin);
			// 		context.lineTo(160 + 36 + mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 		context.lineTo(160 - mobileTouchMargin, 520 + 37 + mobileTouchMargin);
			// 		context.lineTo(160 - mobileTouchMargin, 520 - mobileTouchMargin);
			// 	}
			// 	
			// 	context.stroke();
		}
		
	}
	
	context.drawImage(UpperPlatform, backgroundScrollX + 12100, backgroundScrollY + -550);
	
	if(mainBugsby.X > 7800 && mainBugsby.X < 8400 && mainBugsby.Y > -50 && !mainBugsby.dying && !Halfway)
	{
		Halfway = true;
		Stars.push(new Flag(7853,304,Math.floor(Math.random() * 20), -10 + -1 * Math.floor(Math.random() * 20)));
	}
	
	if(!Halfway)
	{
		context.drawImage(Flagpole1, backgroundScrollX + 7800, backgroundScrollY + 262);
	}
	else
	{
		context.drawImage(Flagpole2, backgroundScrollX + 7800, backgroundScrollY + 262);
	}
	stuffDrawn += 1;
	
	if(mainBugsby.X > 15800 && !Wholeway)
	{
		Wholeway = true;
		Stars.push(new Flag(15853,204,Math.floor(Math.random() * 20), -10 + -1 * Math.floor(Math.random() * 20)));
	}
	
	if(!Wholeway)
	{
		context.drawImage(Flagpole1, backgroundScrollX + 15800, backgroundScrollY + 162);
	}
	else
	{
		context.drawImage(Flagpole2, backgroundScrollX + 15800, backgroundScrollY + 162);
	}
	stuffDrawn += 1;
	
	for(var i = 0, len = Items.length; i < len; i++)
	{
		item = Items[i];
		if(item.X + item.rightBound + backgroundScrollX > clippingMargin
			&& item.X + item.leftBound + backgroundScrollX < WIDTH - clippingMargin
			&& item.Y + item.bottomBound + backgroundScrollY > clippingMargin
			&& item.Y - item.topBound + backgroundScrollY < HEIGHT - clippingMargin)
		{
			item.Draw(context);
			stuffDrawn += 1;
		}
	}
	
	for(var i = 0, len = Cubes.length; i < len; i++)
	{
		cube = Cubes[i];
		if(cube.X + cube.width + backgroundScrollX > clippingMargin
			&& cube.X - cube.width + backgroundScrollX < WIDTH - clippingMargin
			&& cube.Y + cube.height + backgroundScrollY > clippingMargin
			&& cube.Y - cube.height + backgroundScrollY < HEIGHT - clippingMargin)
		{
			cube.Draw(context);
			stuffDrawn += 1;
		}
	}
	
	for(var i = 0, len = Baddies.length; i < len; i++)
	{
		baddie = Baddies[i];
		if(baddie.X + baddie.rightBound + backgroundScrollX > clippingMargin
			&& baddie.X + baddie.leftBound + backgroundScrollX < WIDTH - clippingMargin
			&& baddie.Y + baddie.bottomBound + backgroundScrollY > clippingMargin
			&& baddie.Y - baddie.topBound + backgroundScrollY < HEIGHT - clippingMargin)
		{
			baddie.Draw(context);
			stuffDrawn +=1;
		}
	}
	
	for(var i = 0, len = Platforms.length; i < len; i++)
	{
		platform = Platforms[i];
		if(platform.type == "moving" || platform.type == "sliding")
		{
			if(platform.right + backgroundScrollX > clippingMargin
				&& platform.left + backgroundScrollX < WIDTH - clippingMargin
				&& platform.top + 150 + backgroundScrollY > clippingMargin
				&& platform.top - 150 + backgroundScrollY < HEIGHT - clippingMargin)
			{
				platform.Draw(context);
				stuffDrawn += 1;
			}
		}
	}
	
	mainBugsby.Draw(context);
	
	for(var i = 0, len = Stars.length; i < len; i++)
	{
		star = Stars[i];
		if(star.X + 15 + backgroundScrollX > clippingMargin
			&& star.X - 15 + backgroundScrollX < WIDTH - clippingMargin
			&& star.Y + 15 + backgroundScrollY > clippingMargin
			&& star.Y - 15 + backgroundScrollY < HEIGHT - clippingMargin)
		{
			star.Draw(context);
			stuffDrawn += 1;
		}
	}
	
	if(debugMode)
	{
		for(var i = 0, len = Platforms.length; i < len; i++)
		{
			platform = Platforms[i];
			platform.DebugDraw(context);
			//stuffDrawn += 1;
		}
		
		for(var i = 0, len = Walls.length; i < len; i++)
		{
			wall = Walls[i];
			wall.DebugDraw(context);
			//stuffDrawn += 1;
		}
	}

	//context.drawImage(houseOverlay, backgroundScrollX + 6141, backgroundScrollY + 324);
	
	context.drawImage(CookieSprite, 10, 10);
	stuffDrawn += 1;
	
	if(mainBugsby.tracksuitPower)
	{
		context.drawImage(cartwheelAttackInfo, 150, 10);
		stuffDrawn += 1;
	}
	
	PrintNumber(context, 40, 20, NumCookies);
	
	if(debugMode && mainBugsby.X >= 0) PrintNumber(context, 700, 20, Math.floor(mainBugsby.X));
	if(debugMode && mainBugsby.Y >= 0) PrintNumber(context, 700, 40, Math.floor(mainBugsby.Y));
	

	if(Wiping)
	{
		DrawTorus(context, WipeCenterX + backgroundScrollX, WipeCenterY + backgroundScrollY, WipeInnerRadius,WipeOuterRadius);
	}
	
	if(isMobile || debugMode)
	{
		PrintNumber(context, 700, 60, frameRate);
		PrintNumber(context, 700, 80, stuffDrawn);
	}
}

Numbers = new Array(10);
var n;
for(n = 0; n < 10; n++)
{
	Numbers[n] = new Image();
	Numbers[n].src = n.toString() + '.png';
}

function PrintNumber(context, x, y, number)
{
	numString = number.toString();
	var i;
	for(i = 0; i < numString.length; i++)
	{
		context.drawImage(Numbers[numString.charAt(i)], x + 22 * i, y);
	}
}

WipeOuterRadius = 1500;
WipeInnerRadius = 1500;
WipeCenterX = 0;
WipeCenterY = 0;
Wiping = false;

function DrawWipe()
{
	DrawTorus()
}

TorusGranularity = 36;

function DrawTorus(context, centerX, centerY, innerRadius, outerRadius)
{
	//draw a torus
	context.fillStyle = "#000000";
	
	var i = 0;
	for(i = 0; i < TorusGranularity; i++)
	{
		context.beginPath();
		context.moveTo(centerX + innerRadius * Math.cos(2 * i * Math.PI / TorusGranularity),
						centerY + innerRadius * Math.sin(2 * i * Math.PI / TorusGranularity));
		context.lineTo(centerX + outerRadius * Math.cos(2 * i * Math.PI / TorusGranularity),
						centerY + outerRadius * Math.sin(2 * i * Math.PI / TorusGranularity));
		context.lineTo(centerX + outerRadius * Math.cos(2 * (i + 1.1) * Math.PI / TorusGranularity),
						centerY + outerRadius * Math.sin(2 * (i + 1.1) * Math.PI / TorusGranularity));
		context.lineTo(centerX + innerRadius * Math.cos(2 * (i + 1.1) * Math.PI / TorusGranularity),
						centerY + innerRadius * Math.sin(2 * (i + 1.1) * Math.PI / TorusGranularity));
		context.lineTo(centerX + innerRadius * Math.cos(2 * i * Math.PI / TorusGranularity),
						centerY + innerRadius * Math.sin(2 * i * Math.PI / TorusGranularity));
		context.fill();
	}
}

function findPos(element)
{
	var curLeft = 0;
	var curTop = 0;
	if(element.offsetParent)
	{
		do{
			curLeft += element.offsetLeft;
			curTop += element.offsetTop;
		} while(element = element.offsetParent);
	}
	
	return [curLeft, curTop];
}

leftKeyDown = false;
rightKeyDown = false;
spaceKeyDown = false;

function KeyDown(ev)
{	
	//console.log(ev.keyCode);
	if(ev.keyCode == 37)
	{
		ev.preventDefault();
		leftKeyDown = true;
	}
	
	if(ev.keyCode == 39)
	{
		ev.preventDefault();
		rightKeyDown = true;
	}
	
	if(ev.keyCode == 32 && mainBugsby.VY == 0 && !mainBugsby.falling && !mainBugsby.ideaPower)
	{
		//console.log(mainBugsby.X);
		mainBugsby.falling = true;
		mainBugsby.platform = null;
		mainBugsby.VY -= BugsbyJumpPower;
		if(mainBugsby.tracksuitPower)
		{
			mainBugsby.VY -= BugsbyJumpPower / 4;
		}
		if(mainBugsby.cartwheeling)
		{
			this.cartwheelTimer = 0;
			this.cartwheelAngle = 0;
			this.cartwheelDirection = 0;
			this.cartwheeling = false;
		}
	}
	
	if(ev.keyCode == 88
		&& mainBugsby.tracksuitPower)
	{
		if(leftKeyDown && (!mainBugsby.cartwheeling || mainBugsby.cartwheelTimer < 3 || mainBugsby.cartwheelDirection == 1))
		{
			mainBugsby.cartwheeling = true;
			mainBugsby.cartwheelTimer = 15;
			mainBugsby.cartwheelAngle = 0;
			mainBugsby.cartwheelDirection = -1;
			mainBugsby.VX = 0;
		}
		else if(rightKeyDown && (!mainBugsby.cartwheeling || mainBugsby.cartwheelTimer < 3 || mainBugsby.cartwheelDirection == -1))
		{
			mainBugsby.cartwheeling = true;
			mainBugsby.cartwheelTimer = 15;
			mainBugsby.cartwheelAngle = 0;
			mainBugsby.cartwheelDirection = 1;
			mainBugsby.VX = 0;
		}
	}
	
	if(ev.keyCode == 32 && mainBugsby.ideaPower)
	{
		spaceKeyDown = true;
	}
}

function KeyUp(ev)
{	
	if(ev.keyCode == 37)
	{
		ev.preventDefault();
		leftKeyDown = false;
	}
	
	if(ev.keyCode == 39)
	{
		ev.preventDefault();
		rightKeyDown = false;
	}
	
	if(ev.keyCode == 32)
	{
		spaceKeyDown = false;
		if(mainBugsby.ideaPower && !mainBugsby.falling) mainBugsby.falling = true;
	}
}

function KeyPress(ev)
{
	if(ev.keyCode == 37)
	{
		ev.preventDefault();
	}
	
	if(ev.keyCode == 39)
	{
		ev.preventDefault();
	}
}



function appTouchmove(ev)
{
    ev.preventDefault();
	if(ev.changedTouches.length >= 1)
	{
		var touch = ev.changedTouches[0];
		var x = touch.pageX - canvas.left;
		var y = touch.pageY - canvas.top;
		
		var bx = mainBugsby.X + backgroundScrollX;
		var by = mainBugsby.Y + backgroundScrollY;
		
		if(y < startY - 10)
		{
			if(mainBugsby.VY == 0 && !mainBugsby.falling && !mainBugsby.ideaPower)
			{
				mainBugsby.falling = true;
				mainBugsby.platform = null;
				mainBugsby.VY -= BugsbyJumpPower;
				if(mainBugsby.tracksuitPower)
				{
					mainBugsby.VY -= BugsbyJumpPower / 4;
				}
				if(mainBugsby.cartwheeling)
				{
					this.cartwheelTimer = 0;
					this.cartwheelAngle = 0;
					this.cartwheelDirection = 0;
					this.cartwheeling = false;
				}
			}
			
			if(mainBugsby.ideaPower)
			{
				spaceKeyDown = true;
			}
		}
		
		if(x > bx + 20)
		{
			rightKeyDown = true;
			leftKeyDown = false;
		}

		if(x < bx - 20)
		{
			leftKeyDown = true;
			rightKeyDown = false;
		}
		
		startY = y;
	}
}
    
startX = null;
startY = null;
function appTouchstart(ev)
{
	ev.preventDefault();
	if(ev.targetTouches.length >= 1)
	{
		var touch = ev.targetTouches[0];
		var x = touch.pageX - canvas.left;
		var y = touch.pageY - canvas.top;
		
		var bx = mainBugsby.X + backgroundScrollX;
		var by = mainBugsby.Y + backgroundScrollY;
		
		if(x > bx + 20)
		{
			rightKeyDown = true;
			leftKeyDown = false;
		}

		if(x < bx - 20)
		{
			leftKeyDown = true;
			rightKeyDown = false;
		}
		
		startY = y;
	}
}

function appTouchend(ev)
{
	ev.preventDefault();
	
	leftKeyDown = false;
	rightKeyDown = false;
	spaceKeyDown = false;	
}

/*
function appTouchmove(ev)
{
    ev.preventDefault();
	if(ev.changedTouches.length >= 1)
	{
		for(var i = 0; i < ev.changedTouches.length; i++)
		{
			var touch = ev.changedTouches[i];
			var x = touch.pageX - canvas.left;
			var y = touch.pageY - canvas.top;
		
			if(x < canvas.width / 2)
			{
				if(x > startX + 5)
				{
					rightKeyDown = true;
					leftKeyDown = false;
				}
		
				if(x < startX - 5)
				{
					leftKeyDown = true;
					rightKeyDown = false;
				}
				
				startX = x;
			}
			else if(x > canvas.width / 2)
			{
				if(y < startY - 10)
				{
					if(mainBugsby.VY == 0 && !mainBugsby.falling && !mainBugsby.ideaPower)
					{
						mainBugsby.falling = true;
						mainBugsby.platform = null;
						mainBugsby.VY -= BugsbyJumpPower;
						if(mainBugsby.tracksuitPower)
						{
							mainBugsby.VY -= BugsbyJumpPower / 4;
						}
						if(mainBugsby.cartwheeling)
						{
							this.cartwheelTimer = 0;
							this.cartwheelAngle = 0;
							this.cartwheelDirection = 0;
							this.cartwheeling = false;
						}
					}
		
					if(mainBugsby.ideaPower)
					{
						spaceKeyDown = true;
					}
				}
				
				startY = y;
			}
		}
	}
}
    
startX = null;
startY = null;
function appTouchstart(ev)
{
	ev.preventDefault();
	if(ev.targetTouches.length >= 1)
	{
		for(var i = 0; i < ev.targetTouches.length; i++)
		{
			var touch = ev.targetTouches[i];
			var x = touch.pageX - canvas.left;
			var y = touch.pageY - canvas.top;
			
			if(x < canvas.width / 2)
			{
				startX = touch.pageX - canvas.left;
			}
			else if(x > canvas.width / 2)
			{
				startY = touch.pageY - canvas.top;
			}
		}
	}
}

function appTouchend(ev)
{
	ev.preventDefault();
	
	for(var i = 0; i < ev.changedTouches.length; i++)
	{
		var touch = ev.changedTouches[i];
		var x = touch.pageX - canvas.left;
		var y = touch.pageY - canvas.top;
	
		if(x < canvas.width / 2)
		{
			leftKeyDown = false;
			rightKeyDown = false;
		}
		else if(x > canvas.width / 2)
		{
			spaceKeyDown = false;
		}
	}
	
	
}*/


/*
function appTouchmove(ev)
{
    ev.preventDefault(); 
}
    
function appTouchstart(ev)
{
    ev.preventDefault();
	for(var i = 0; i < ev.targetTouches.length; i++)
	{
		var touch = ev.targetTouches[i];
		var x = touch.pageX - canvas.left;
		var y = touch.pageY - canvas.top;
		
		// console.log("X: " + x);
		// 		console.log("Y: " + y);
		// 		console.log("Canvas: " + canvas.width);
		
		if(x >= 660 - mobileTouchMargin && x <= 660 + 36 + mobileTouchMargin
			&& y >= 520 - mobileTouchMargin && y <= 520 + 37 + mobileTouchMargin)
		{
			//console.log("going left");
			leftKeyDown = true;
		}
		
		if(x >= 740 - mobileTouchMargin && x <= 740 + 36 + mobileTouchMargin
			&& y >= 520 - mobileTouchMargin && y <= 520 + 37 + mobileTouchMargin)
		{
			//console.log("going left");
			rightKeyDown = true;
		}
		
		if(x >= 20 - mobileTouchMargin && x <= 20 + 102 + mobileTouchMargin
			&& y >= 520 - mobileTouchMargin && y <= 520 + 37 + mobileTouchMargin)
		{
			if(mainBugsby.VY == 0 && !mainBugsby.falling && !mainBugsby.ideaPower)
			{
				mainBugsby.falling = true;
				mainBugsby.platform = null;
				mainBugsby.VY -= BugsbyJumpPower;
				if(mainBugsby.tracksuitPower)
				{
					mainBugsby.VY -= BugsbyJumpPower / 4;
				}
				if(mainBugsby.cartwheeling)
				{
					this.cartwheelTimer = 0;
					this.cartwheelAngle = 0;
					this.cartwheelDirection = 0;
					this.cartwheeling = false;
				}
			}
			
			if(mainBugsby.ideaPower)
			{
				spaceKeyDown = true;
			}
		}
		
		if(x >= 160 - mobileTouchMargin && x <= 160 + 36 + mobileTouchMargin
			&& y >= 520 - mobileTouchMargin && y <= 520 + 37 + mobileTouchMargin)
		{
			if(mainBugsby.tracksuitPower)
			{
				if(leftKeyDown && (!mainBugsby.cartwheeling || mainBugsby.cartwheelTimer < 3 || mainBugsby.cartwheelDirection == 1))
				{
					mainBugsby.cartwheeling = true;
					mainBugsby.cartwheelTimer = 15;
					mainBugsby.cartwheelAngle = 0;
					mainBugsby.cartwheelDirection = -1;
					mainBugsby.VX = 0;
				}
				else if(rightKeyDown && (!mainBugsby.cartwheeling || mainBugsby.cartwheelTimer < 3 || mainBugsby.cartwheelDirection == -1))
				{
					mainBugsby.cartwheeling = true;
					mainBugsby.cartwheelTimer = 15;
					mainBugsby.cartwheelAngle = 0;
					mainBugsby.cartwheelDirection = 1;
					mainBugsby.VX = 0;
				}
			}
		}
	}			
}

function appTouchend(ev)
{
	ev.preventDefault();
	for(var i = 0; i < ev.changedTouches.length; i++)
	{
		var touch = ev.changedTouches[i];
		var x = touch.pageX - canvas.left;
		var y = touch.pageY - canvas.top;
		
		if(x >= 600)
		{
			rightKeyDown = false;
			leftKeyDown = false;
		}
		
		if(x < 140)
		{
			spaceKeyDown = false;
			if(mainBugsby.ideaPower && !mainBugsby.falling) mainBugsby.falling = true;
		}
	}
}
*/

